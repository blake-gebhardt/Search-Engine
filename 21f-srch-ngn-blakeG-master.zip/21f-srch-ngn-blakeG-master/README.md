# Fall 2021 Final Project 

## Important:

- You DO NOT need to implement GitHub Actions for the final project.  
- DO NOT attempt to push the data set for this project to Github.  

## Links:

- [Final Project Handout](https://docs.google.com/document/d/1iKdp9c4WrrGjgHpJKb94H3mZb0PCYJLEV0gCnLe19aw/edit?usp=sharing)
- [Final Project Slide Deck](https://docs.google.com/presentation/d/1nuay20kigz95I6EUIbpLVTJqALJc-1HoqI1GsgWLWzQ/edit?usp=sharing)
- Tutorial on RapidJSON by TA Christian > [here](https://github.com/Gouldilocks/rapidTutorial) <. 