//
// Created by MARK FONTENOT on 9/14/21.
//

#ifndef INC_21F_PA04_CATCH_SETUP_H
#define INC_21F_PA04_CATCH_SETUP_H
int runCatchTests();
#endif //INC_21F_PA04_CATCH_SETUP_H
